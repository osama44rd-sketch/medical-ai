# نشر Medical AI أونلاين

## الطريقة الأسهل: Render
1. أنشئ حساباً على Render.
2. ارفع هذا المشروع إلى GitHub.
3. في Render اختر New > Web Service ثم اربط مستودع GitHub.
4. Render سيقرأ `render.yaml` أو اختر Docker.
5. أضف Secret باسم `OPENAI_API_KEY` وضع مفتاح API الخاص بك.
6. انشر الخدمة.
7. افتح رابط الموقع الذي يعطيه Render.

لا تضع مفتاح OpenAI داخل `index.html` أو أي ملف JavaScript للمتصفح.

المشروع يستخدم OpenAI Responses API من الخادم.
