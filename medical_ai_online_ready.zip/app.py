import os
from fastapi import FastAPI
from fastapi.responses import FileResponse
from pydantic import BaseModel
from openai import OpenAI

app = FastAPI(title="Medical AI — عاصم اسامه معجوز")

api_key = os.getenv("OPENAI_API_KEY")
model = os.getenv("OPENAI_MODEL", "gpt-5.6")
client = OpenAI(api_key=api_key) if api_key else None

SYSTEM = """
أنت Medical AI Assistant، مساعد معلومات صحية عامة باللغة العربية.
المطور: عاصم اسامه معجوز.

السلامة:
- لا تدّعي أنك طبيب.
- لا تقدم تشخيصاً مؤكداً من الأعراض وحدها.
- لا تصف علاجاً أو جرعات شخصية كبديل للطبيب.
- قدم معلومات عامة واطلب معلومات متابعة عند الحاجة.
- إذا كانت هناك علامات خطر محتملة، وضّح أن المستخدم يحتاج تقييماً طبياً عاجلاً.
- في الطوارئ لا تؤخر طلب المساعدة الطبية بسبب المحادثة.
- لا تطلب بيانات شخصية غير ضرورية.
"""

class Chat(BaseModel):
    message: str

@app.get("/")
def home():
    return FileResponse("static/index.html")

@app.get("/health")
def health():
    return {"ok": True, "developer": "عاصم اسامه معجوز"}

@app.post("/chat")
def chat(body: Chat):
    if not body.message.strip():
        return {"answer": "اكتب سؤالك الصحي أولاً."}

    if client is None:
        return {"answer": "الخادم لم يتم إعداد مفتاح الذكاء الاصطناعي عليه بعد."}

    try:
        r = client.responses.create(
            model=model,
            instructions=SYSTEM,
            input=body.message.strip()
        )
        return {"answer": r.output_text}
    except Exception as e:
        print("OpenAI error:", repr(e))
        return {"answer": "حدث خطأ في خدمة الذكاء الاصطناعي. تأكد من إعداد مفتاح API وصلاحيته."}
